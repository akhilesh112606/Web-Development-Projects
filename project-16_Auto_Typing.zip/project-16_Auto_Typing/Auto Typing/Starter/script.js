// Setting up and Starting the Auto Typing Effect

var typed = new Typed('.auto-type', {
    strings: ['DSA freak.', 'WebDev guy.', 'Content Creator.'],
    typeSpeed: 50,
    backSpeed: 50,
    loop : true,
    backDelay: 1000,
    cursorChar: '|',
    smartBackspace : true
});