// Creating a Function to Calculate Tip
function calculateTip(){
    let bill = parseFloat(document.getElementById("bill").value);
    let service = parseFloat(document.getElementById("service").value);
    let people = parseFloat(document.getElementById("people").value);

    // Validations
    if(!isFinite(bill) || bill <=0){
        alert("Please enter a valid bill");
        return;
    }

    if(people < 1){
        alert("Please enter atleast 1 person");
    }

    // Calcualte the Tip Vlaues
    const tipAmount = bill*service;
    const totalAmount = bill + tipAmount;
    const perPerson = totalAmount / people;
    const tipPerPerson = tipAmount / people;

    // Display the Result with 2 Decimal Places
    document.getElementById("tipAmount").textContent = `$${tipAmount.toFixed(2)}`;
    document.getElementById("totalAmount").textContent = `$${totalAmount.toFixed(2)}`;
    document.getElementById("perPerson").textContent = `$${perPerson.toFixed(2)}`;
    document.getElementById("tipPerPerson").textContent = `$${tipPerPerson.toFixed(2)}`;
}

// Calculate based on Input Change
document.querySelectorAll('input, select').forEach((ele)=>{
    ele.addEventListener('input', calculateTip);
})

