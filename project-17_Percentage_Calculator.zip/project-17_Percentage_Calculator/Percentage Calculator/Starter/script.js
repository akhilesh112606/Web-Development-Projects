const calculateBtn = document.getElementById("calculateBtn");
const numberInput = document.getElementById("number");
const percentInput = document.getElementById("percent");
const percentageResult = document.getElementById("percentageResult");
const finalResult = document.getElementById("finalResult");
const errorDisplay = document.getElementsByClassName("error")[0];

function calculatePercentage(){
    errorDisplay.textContent = "";
    let amount = parseFloat(numberInput.value);
    let percent = parseFloat(percentInput.value);

    if(amount < 0.0 || percent < 0.0 || percent > 100.0){
        errorDisplay.textContent = "Please enter the inputs properly";
    }

    let percentageAmount = (percent*amount)/100;
    let finalAns = amount + percentageAmount;
    
    percentageResult.innerHTML = `$${percentageAmount}`;
    finalResult.innerHTML = `$${finalAns}`
}

calculateBtn.addEventListener("click", calculatePercentage);