// Make sure that all assets are loaded

document.addEventListener('DOMContentLoaded', ()=>{
    // API Request : https://jsonplaceholder.typicode.com/posts
    const postContainer = document.querySelector('.posts-container');
    const APIurl = "https://jsonplaceholder.typicode.com/posts";
    async function fetchPosts(){
        try{
            // Make HTTP Request
            const response = await fetch(APIurl);
            const posts = await response.json();
            
            // We are having the data so Clear the Loading Message
            postContainer.innerHTML = "";

            // Displaying the posts, each
            posts.forEach(post => {
                const postElement = createPostElement(post);
                postContainer.appendChild(postElement);
            });

        }

        catch(error){
            console.log(error);
        }
    }
    // Creating a Function to Create a card in the frontend using HTML
    function createPostElement(post){
        const article = document.createElement("article");
        article.className = "post-card";
        
        const title = document.createElement("h2");
        title.className = "post-title";
        title.textContent = post.title;

        const body = document.createElement("p");
        body.className = "post-body";
        body.textContent = post.body;
        
        article.appendChild(title);
        article.appendChild(body);
        
        return article;
    }    

    fetchPosts();
})