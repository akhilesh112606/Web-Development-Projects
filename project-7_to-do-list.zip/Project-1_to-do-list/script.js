document.addEventListener('DOMContentLoaded', () => {
  const to_do_input = document.getElementById("todo-input")
  const add_task_button = document.getElementById("add-task-btn")
  const to_do_list = document.getElementById("todo-list")

  let tasks = JSON.parse(localStorage.getItem("tasks")) || []

  tasks.forEach(element => renderTask(element));

  add_task_button.addEventListener('click', () => {
    const to_do_text = to_do_input.value.trim()
    if(to_do_text === "") return;

    const newTask = {
      id : Date.now(),
      text : to_do_text,
      completed : false,
    }

    tasks.push(newTask);
    to_do_input.value = "";
    saveData();
    renderTask(newTask)
    console.log(tasks)
  })

  function renderTask(task){
    const li = document.createElement('li');
    li.setAttribute('data-id', task.id);
    if(task.completed) li.classList.add('completed')
    li.innerHTML = `
    <span> ${task.text} </span>
    <button> Delete </button>
    `;
    
    li.addEventListener('click', (e) => {
      if(e.target.tagName === "BUTTON") return 
      task.completed = !task.completed;
      li.classList.toggle('completed')
      saveData()
    })

    li.querySelector('button').addEventListener('click', (e) => {
      e.stopPropagation()
      tasks = tasks.filter(t => t.id !== task.id)
      li.remove()
      saveData()
    })
    
    to_do_list.appendChild(li)
  }

  function saveData(){
    localStorage.setItem("tasks", JSON.stringify(tasks));
  } 
})