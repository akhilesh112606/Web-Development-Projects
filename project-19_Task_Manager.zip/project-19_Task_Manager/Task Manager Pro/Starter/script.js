let currfilter = "all";
const toDo = JSON.parse(localStorage.getItem("todos")) || [];

function saveToDo() {
  localStorage.setItem("todos", JSON.stringify(toDo));
}

function renderToDo() {
  const todoList = document.getElementById("todoList");
  todoList.innerHTML = "";
  const filteredTodo = toDo.filter((to) => {
    if (currfilter === "completed") return to.completed;
    if (currfilter === "pending") return !to.completed;
    return true;
  });

  filteredTodo.forEach((todo, index) => {
    const li = document.createElement("li");
    if (todo.completed) {
      li.classList.add("completed");
    }

    li.innerHTML = `
    <div class="todo-content">
        <span class="todo-text">${todo.text}</span>
    </div>

    <div class="todo-actions">
        <button data-index="${index}" class="action-btn complete-btn">
        <i class="fas ${todo.completed ? "fa-rotate-left" : "fa-check"}"></i>
        </button>

        <button data-index="${index}" class="action-btn delete-btn">
        <i class="fas fa-trash"></i>
        </button>
    </div>
    `;

    todoList.appendChild(li);
  });
}

function addToDo() {
  const inputField = document.getElementById("todoInput");
  const text = inputField.value.trim();
  if (text) {
    toDo.push({
      text: text,
      completed: false,
    });
  }

  inputField.value = "";
  saveToDo();
  renderToDo();
}

function toggleToDo(index){
    toDo[index].completed = !toDo[index].completed;
    saveToDo();
    renderToDo();
}

function deleteToDo(index){
    toDo.splice(index, 1);
    saveToDo();
    renderToDo();
}

renderToDo();

document.getElementById("addTodoBtn").addEventListener("click", addToDo);
document.getElementById("todoList").addEventListener("click", function(e){
    const target = e.target.closest('button');
    if(!target){
        return;
    }

    const todoIndex = parseInt(target.dataset.index);

    if(target.classList.contains('complete-btn')){
        toggleToDo(todoIndex);
    }

    else if(target.classList.contains('delete-btn')){
        deleteToDo(todoIndex);
    }
})

document.querySelector('[data-filter = "completed"]').addEventListener("click", ()=>{
    currfilter = "completed";
    renderToDo();
})

document.querySelector('[data-filter = "pending"]').addEventListener("click", ()=>{
    currfilter = "pending";
    renderToDo();
})

document.querySelector('[data-filter = "all"]').addEventListener("click", ()=>{
    currfilter = "all";
    renderToDo();
})

