document.addEventListener('DOMContentLoaded', () => {
  const cityInput = document.getElementById("city-input");
  const getWeatherBTN = document.getElementById("get-weather-btn");
  const weatherInfo = document.getElementById("weather-info")
  const cityNameDisplay = document.getElementById("city-name")
  const tempDisplay = document.getElementById("temperature")
  const descriptionDisplay = document.getElementById("description")
  const errorMessage = document.getElementById("error-message")
  const API_KEY = "a1b2394289828346d954d42d376a1033"

  getWeatherBTN.addEventListener("click", async() => {
    const city_name = cityInput.value.trim();
    if(!city_name) return;

    try {
      const weatherData = await fetch_weather_data(city_name)
      display_weather_data(weatherData)
    } catch (error) {
      show_error()
    }
  })

  async function fetch_weather_data(cityName){
    // retrieving the data from the API
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${API_KEY}`;
    const response = await fetch(url)
    console.log(response)
    if(!response.ok){
      throw new Error("City Not Found")
    }
    const data = await response.json()
    return data
  }

  function display_weather_data(weather_data){
    const {name, main, weather} = weather_data
    cityNameDisplay.textContent = name
    tempDisplay.textContent = `Temperature : ${main.temp}`
    descriptionDisplay.textContent = `Weather : ${weather[0].description}`

    // Unlocking the display
    weatherInfo.classList.remove('hidden')
    errorMessage.classList.add('hidden')
  }

  function show_error(){
    weatherInfo.classList.add('hidden')
    errorMessage.classList.remove('hidden')
  }

})