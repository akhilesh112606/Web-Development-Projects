// Step 1: Initialize Feather icons for any elements that need icons
//   - Use feather.replace() to replace placeholders with actual icons
feather.replace();
// Step 2: Initialize the application by selecting necessary DOM elements
//   - Select elements for amount input, currency dropdowns, convert button, result display, base currency, get rates button, exchange rates display, mode toggles, and mode sections

const amountInput = document.getElementById("amount");
const fromCurrency = document.getElementById("from-currency");
const toCurrency = document.getElementById("to-currency");
const convertBtn = document.getElementById("convert-btn");
const result = document.getElementById("result");
const baseCurrency = document.getElementById("base-currency");
const getRatesBtn = document.getElementById("get-rates-btn");
const exchangeRates = document.getElementById("exchange-rates");
const convertMode = document.getElementById("convert-mode");
const exchangeMode = document.getElementById("exchange-mode");
const toggleBtns = document.querySelectorAll(".toggle-btn");

// Step 3: Define the API key for accessing the ExchangeRate-API
//   - Set the apiKey variable to your ExchangeRate-API key
const apiKey = "b46f38793af093192c0faf54";

// Step 4: Set up event listeners for toggling between conversion and exchange modes
toggleBtns.forEach((btn)=>{
  btn.addEventListener("click", ()=>{
    toggleBtns.forEach((btn)=>{
      btn.classList.remove('active');
    })
    btn.classList.add("active");
    const mode = btn.getAttribute('data-mode');
    if(mode === "convert"){
      convertMode.style.display = 'flex';
      exchangeMode.style.display = "none";
    }else{
      exchangeMode.style.display = "flex";
      convertMode.style.display = "none";
    }
  })
})

// Step 5: Implement the currency conversion functionality
convertBtn.addEventListener('click', ()=>{
  const amount = amountInput.value;
  const from = fromCurrency.value;
  const to = toCurrency.value;

  fetch(`https://v6.exchangerate-api.com/v6/${apiKey}/pair/${from}/${to}`)
  .then((response) => {
    return response.json();
  })
  .then((data)=>{
    const rate = data.conversion_rate;
    const convertedAmount = (amount * rate).toFixed(2);
    console.log(convertedAmount);
    result.innerHTML = `${convertedAmount}`;
  })
  .then((error) => {
    console.log(error);
  })
});

// Step 6: Implement the exchange rates retrieval functionality
//   - Step 6a: Add a click event listener to the get rates button
getRatesBtn.addEventListener("click", () => {
  const base = baseCurrency.value;
  fetch(`https://v6.exchangerate-api.com/v6/${apiKey}/latest/${base}`)
  .then((response)=>{
    return response.json()
  })
  .then((data)=>{
    let ratesHTML = "<h3>Exchange Rates </h3><ul>"
    for(const [currency, rate] of Object.entries(data.conversion_rates)){
      if(currency !== base){
        ratesHTML += `<li><span class = "currency-icon">${currency}:</span>${currency}: ${rate.toFixed(4)}</li>`;
      }
    }
    ratesHTML += "</ul>";
    exchangeRates.innerHTML = ratesHTML;
  })
  .catch((error)=>{
    exchangeRates.textContent = "Error Occured try again later";
  });
});

// Step 7: Create a helper function to return the appropriate currency symbol based on the currency code
//   - Define a getCurrencySymbol function that maps common currency codes to their symbols

// Step 8: Test the application to ensure all functionality works as expected
//   - Verify that feather.replace() correctly replaces placeholders with icons
//   - Check that the mode toggling works as intended
//   - Ensure that currency conversion is accurate and displayed properly
//   - Validate that exchange rates are correctly retrieved and displayed

// Step 9: Implement error handling to provide user feedback in case of issues with API requests
//   - Ensure that all fetch requests handle errors gracefully and update the UI accordingly

// Step 10: Consider future enhancements, such as adding more currency symbols, improving the UI with animations, or integrating additional features like historical exchange rates or comparison tools
