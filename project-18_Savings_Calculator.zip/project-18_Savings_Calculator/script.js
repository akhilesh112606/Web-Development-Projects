// Initialize Feather icons
feather.replace();

// Roadmap Step 1: Select DOM elements
const goalAmount = document.getElementById("goal-amount");
const currSaving = document.getElementById("current-savings");
const monthContri = document.getElementById("monthly-contribution");

const calculateBtn = document.getElementById("calculate-btn");
const progressBar = document.getElementById("progress-bar");
const result = document.getElementById("result");
const error = document.getElementById("temp");

// Roadmap Step 2: Add event listener for calculate button
calculateBtn.addEventListener("click", ()=>{
    result.classList.remove("show");
    error.textContent = "";
    // Roadmap Step 3: Validate user input
    let amount = parseFloat(goalAmount.value);
    let saving = parseFloat(currSaving.value);
    let monthAmount = parseFloat(monthContri.value);
    if(amount < 0 || saving < 0 || monthAmount < 0){
        console.log("Error triggered");
        error.textContent = "Enter correct values";
        return;
    }

    
    // Roadmap Step 4: Calculate remaining amount and months to reach goal
    let remainingAmount = amount - saving;
    let months = remainingAmount / monthAmount;
    let progressPercentage = (remainingAmount/amount)*100;
    console.log(progressPercentage);

    if(months > 0){
        result.innerHTML = `<p>Keep Nuturing your Savings! You will reach your goal amount within ${Math.ceil(months)} Months!</p>`
    }

    else{
        result.innerHTML = `Congo! You already reached your Savings!`;
    }
    progressBar.style.width = `${progressPercentage}%`;
    result.classList.add("show");    
});