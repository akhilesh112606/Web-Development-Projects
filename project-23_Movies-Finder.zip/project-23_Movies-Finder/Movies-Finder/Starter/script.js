//http://img.omdbapi.com/?apikey=f08cbe6c&s=mummy

document.addEventListener('DOMContentLoaded', ()=>{
    const movieForm = document.getElementById("movieForm");
    const movieResult = document.getElementById("movieResults");
    movieForm.addEventListener('submit', async (e)=>{
            e.preventDefault();
        const movieName = document.getElementById("movieInput").value;
        await fetchMovies(movieName);
    })

    // Search for Movies
    async function fetchMovies(movieName){
        try {
            // Loading
            movieResult.innerHTML = '<div class="loading"> Searching Movies.. </div>';
            const response = await fetch(`http://www.omdbapi.com/?s=${movieName}&apikey=14e82aca`);
            const data = await response.json();
            if(data.Response === 'False'){
                throw new Error('No movies Found');
            }
            displayMovies(data.Search);
        } catch (error) {
            movieResult.innerHTML = `
                <div class = 'error-message'>
                    "Error Searching Movies. Please try again"
                </div>
            `
        }
    }

    function displayMovies(movies) {
    movieResult.innerHTML = `
              <div class="movies-grid">
                  ${movies
                    .map(
                      (movie) => `
                      <div class="movie-card">
                          <img 
                              src="${
                                movie.Poster !== "N/A"
                                  ? movie.Poster
                                  : "https://via.placeholder.com/300x450?text=No+Poster"
                              }" 
                              alt="${movie.Title}"
                              class="movie-poster"
                             
                          >
                          <div class="movie-info">
                              <h3 class="movie-title">${movie.Title}</h3>
                              <div class="movie-year">${movie.Year}</div>
                          </div>
                      </div>
                  `
                    )
                    .join("")}
              </div>
          `;
  }
})