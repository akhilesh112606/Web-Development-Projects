const http = require('http');
const os = require('os');
const { parse } = require('path');
const process = require('process');
const url = require('url');

// Format Bytes to Human _ Readable Format
function formatBytes(bytes, decimal=2){
    if(bytes === 0) return '0 bytes';
    // Set base Unit
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const i = Math.floor(Math.log(bytes)/Math.log(k));
    return parseFloat((bytes/Math.pow(k, i))).toFixed(decimal) + ' ' + sizes[i];
}

// Format Seconds to Human readable time
function formatTime(seconds){
    const days = Math.floor(seconds/(3600 * 24));
    const hours = Math.floor( (seconds % (3600 * 24)) / (3600));
    const minutes = Math.floor( (seconds % 3600) / 60);
    const second = Math.floor((seconds % 60));
    return `${days}D - ${hours}H - ${minutes}M - ${second}S`;
}

// console.log(os.cpus()[0]);

//! Get CPU Info
const getCpuInfo =() =>{
    const model = os.cpus()[0].model;
    const cores = os.cpus().length;
    const architecture = os.arch();
    const loadAvg = os.loadavg();

    return {
        model, cores, architecture, loadAvg
    };
}

// Get Memory Info
const getMemoryInfo = () => {
    const total = os.totalmem;
    const free = os.freemem;
    console.log("Total : " + formatBytes(total));
    console.log("Free  : " + formatBytes(free));
}

// In the next step we will be getting the OS Related info 

const canGetOsInfo = ()=>{
    const platform = os.platform();
    const type = os.type();
    const release = os.release();
    const hostName = os.hostname();
    const uptime = os.uptime();
    return {
        type,
        platform,
        release,
        hostName,
        uptime
    };
}

const getUserInfo = ()=>{
    const user = os.getUserInfo();
    return user;
}

const networkInfo = ()=>{
    const network = os.networkInterfaces();
    console.log(network);
}

const getProcessInfo = ()=>{
    const pid = process.pid;
    const title = process.title;
    const nodeVersion = process.version;
    const uptime = process.uptime();
    console.log({
        pid,
        title,
        nodeVersion,
        uptime
    })
}

//! HTTP SERVER
const server = http.createServer((req, res)=>{
    const parsedUrl = url.parse(req.url, true);
    res.setHeader("Content-Type", "application/json");

    // Home Page
    if(parsedUrl.pathname === "/"){
        res.statusCode = 200;
        res.end(JSON.stringify({
            name:"System-View Info API",
            description: "Access the System Info using a Simple Interface",
            routes: ['/cpu', '/memory', '/user', '/process', '/network'],
        }))
    }

    else if(parsedUrl.pathname === "/cpu"){
        res.statusCode = 200;
        res.end(JSON.stringify(getCpuInfo(), null, 2));
    }

    else if(parsedUrl.pathname === "/cpu"){
        res.statusCode = 200;
        res.end(JSON.stringify(getCpuInfo(), null, 2));
    }

    else if(parsedUrl.pathname === "/memory"){
        res.statusCode = 200;
        res.end(JSON.stringify(getMemoryInfo(), null, 2));
    }

    else if(parsedUrl.pathname === "/user"){
        res.statusCode = 200;
        res.end(JSON.stringify(getUserInfo(), null, 2));
    }

    else if(parsedUrl.pathname === "/process"){
        res.statusCode = 200;
        res.end(JSON.stringify(getProcessInfo(), null, 2));
    }

    else if(parsedUrl.pathname === "/network"){
        res.statusCode = 200;
        res.end(JSON.stringify(networkInfo(), null, 2));
    }

    else if(parsedUrl.pathname === "/os"){
        res.statusCode = 200;
        res.end(JSON.stringify(canGetOsInfo(), null, 2));
    }

    else{
        res.statusCode = 404;
        res.end("Invalid Path");
    }
})

//! START THE SERVER    
const PORT = 5000;
server.listen(PORT, ()=>{
    console.log(`Server is running at http://localhost:${PORT}`);
})